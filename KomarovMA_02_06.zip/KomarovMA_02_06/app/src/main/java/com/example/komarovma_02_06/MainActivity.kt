package com.example.komarovma_02_06

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment

class MainActivity : AppCompatActivity() {
    lateinit var passwordText:EditText
    lateinit var emailText:EditText
    lateinit var button:Button


    @SuppressLint("CommitPrefEdits")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        passwordText=findViewById(R.id.passwordText)
        emailText=findViewById(R.id.emailText)
        button=findViewById(R.id.ButtonLogIn)

        button.setOnClickListener {
            var sh: SharedPreferences =getSharedPreferences("PreferencesName",MODE_PRIVATE)
            var emailSave:String = sh.getString("email","").toString()
            var passwordSave:String = sh.getString("password","").toString()


            var emailInput : String = emailText.text.toString()
            var passwordInput : String = passwordText.text.toString()

            if(emailInput == "" || passwordInput =="")
            {
                var alertDialog=AlertDialog.Builder(this)
                alertDialog
                    .setMessage("Пустые поля!")
                    .setPositiveButton("ОК") {
                            dialog, id ->  dialog.cancel()
                    }
                alertDialog.create()
                alertDialog.show()
            }
            else
            {
                if(emailSave=="" || passwordSave=="")
                {
                var editor=sh.edit()

                    editor.putString("email", emailInput)
                    editor.putString("password", passwordInput)
                    editor.apply()

                    var intent: Intent
                    intent= Intent(this, ChatsActivity::class.java)
                    startActivity(intent)
                }
                else
                {
                    if(emailSave==emailInput && passwordSave==passwordInput)
                    {
                        var intent: Intent
                        intent= Intent(this, ChatsActivity::class.java)
                        startActivity(intent)
                    }
                    else
                    {
                        var alertDialog=AlertDialog.Builder(this)
                        alertDialog
                            .setMessage("Неправильный логин или/и пароль!")
                            .setPositiveButton("ОК") {
                                    dialog, id ->  dialog.cancel()
                            }
                        alertDialog.create()
                        alertDialog.show()
                    }
                }
            }
        }

    }
}